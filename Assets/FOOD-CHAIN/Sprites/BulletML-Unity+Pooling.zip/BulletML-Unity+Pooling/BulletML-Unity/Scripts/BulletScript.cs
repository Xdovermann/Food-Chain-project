﻿// Copyright © 2014 Pixelnest Studio
// This file is subject to the terms and conditions defined in
// file 'LICENSE.md', which is part of this source code package.
using UnityEngine;
using System.Collections;

namespace Pixelnest.BulletML
{
  /// <summary>
  /// Script attached to the bullet sprite
  /// </summary>
  public class BulletScript : MonoBehaviour
  {
    /// <summary>
    /// Rotate the projectile with the fire angle
    /// </summary>
    public bool autoRotation = true;

    /// <summary>
    /// Add those degrees to the rotation
    /// </summary>
    public float autoRotationAngleBonus = 0;

    /// <summary>
    /// Destroy if outside the screen
    /// </summary>
    public bool destroyWhenOutOfScreen = true;

    private Renderer[] renderers;

    void Update()
    {
      // Do we have a valid bullet?
      if (bullet != null)
      {
        // Update data
        bullet.Update();
      }

      // The update may have destroyed the bullet
      if (bullet != null)
      {
        // Change position
        this.transform.position = bullet.position;

        // Orientation
        UpdateRotation();
      }

      // Out of screen + autodestruction
      if (destroyWhenOutOfScreen)
      {
        if (renderers == null)
        {
          renderers = GetComponentsInChildren<Renderer>();
        }

        bool isVisible = true;
        foreach (Renderer r in renderers)
        {
          isVisible &= (r.isVisible);
        }

        if (isVisible == false)
        {
          OnDestroy();
        }
      }
    }

    private void UpdateRotation()
    {
      if (bullet != null)
      {
        if (this.autoRotation)
        {
          this.transform.rotation = Quaternion.identity;
          this.transform.Rotate(0, 0, ((bullet.Direction * Mathf.Rad2Deg) - 90) + autoRotationAngleBonus);
        }
      }
    }

    public void Destroy()
    {
      // Then BulletML
      if (bullet != null)
      {
        bullet.MyBulletManager.RemoveBullet(Bullet);
      }
    }

    void OnDestroy()
    {
      // If the object has been killed by a "Destroy" command, we need to make sure the engine is clean
      Destroy();
    }

    private BulletObject bullet;

    /// <summary>
    /// Attached bullet object
    /// </summary>
    public BulletObject Bullet
    {
      get
      {
        return bullet;
      }
      set
      {
        bullet = value;

        if (bullet != null)
        {
          UpdateRotation();

          bullet.Parent = this.gameObject;
        }
      }
    }
  }
}
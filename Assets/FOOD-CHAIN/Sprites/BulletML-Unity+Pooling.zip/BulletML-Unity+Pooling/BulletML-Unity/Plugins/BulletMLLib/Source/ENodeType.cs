
namespace BulletMLLib
{
  public enum ENodeType
  {
    none,
    aim,
    absolute,
    relative,
    sequence
  };
}
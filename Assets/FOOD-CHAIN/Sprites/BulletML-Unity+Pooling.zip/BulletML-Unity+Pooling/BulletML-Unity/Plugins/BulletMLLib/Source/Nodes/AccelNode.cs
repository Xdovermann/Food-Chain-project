using System;
using System.Xml;

namespace BulletMLLib
{
  public class AccelNode : BulletMLNode
  {
    public AccelNode()
      : base(ENodeName.accel)
    {
    }
  }
}

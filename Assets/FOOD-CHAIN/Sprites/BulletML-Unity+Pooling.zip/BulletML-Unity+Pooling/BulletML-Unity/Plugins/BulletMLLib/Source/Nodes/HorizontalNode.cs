using System;
using System.Xml;

namespace BulletMLLib
{
  public class HorizontalNode : BulletMLNode
  {
    public HorizontalNode()
      : base(ENodeName.horizontal)
    {
    }
  }
}

using System;
using System.Xml;

namespace BulletMLLib
{
  public class RepeatNode : BulletMLNode
  {
    public RepeatNode()
      : base(ENodeName.repeat)
    {
    }
  }
}

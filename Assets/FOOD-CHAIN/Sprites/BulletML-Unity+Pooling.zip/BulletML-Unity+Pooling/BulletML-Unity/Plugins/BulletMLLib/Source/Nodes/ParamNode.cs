using System;
using System.Xml;

namespace BulletMLLib
{
  public class ParamNode : BulletMLNode
  {
    public ParamNode()
      : base(ENodeName.param)
    {
    }
  }
}

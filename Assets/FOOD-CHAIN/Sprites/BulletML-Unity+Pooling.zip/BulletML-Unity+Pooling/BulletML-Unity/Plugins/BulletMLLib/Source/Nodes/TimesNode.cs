using System;
using System.Xml;

namespace BulletMLLib
{
  public class TimesNode : BulletMLNode
  {
    public TimesNode()
      : base(ENodeName.times)
    {
    }
  }
}

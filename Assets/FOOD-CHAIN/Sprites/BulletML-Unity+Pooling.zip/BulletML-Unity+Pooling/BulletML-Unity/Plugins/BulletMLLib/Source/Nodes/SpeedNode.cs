using System;
using System.Xml;

namespace BulletMLLib
{
  public class SpeedNode : BulletMLNode
  {
    public SpeedNode()
      : base(ENodeName.speed)
    {
    }
  }
}

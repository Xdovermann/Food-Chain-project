using System;
using System.Xml;

namespace BulletMLLib
{
  public class WaitNode : BulletMLNode
  {
    public WaitNode()
      : base(ENodeName.wait)
    {
    }
  }
}

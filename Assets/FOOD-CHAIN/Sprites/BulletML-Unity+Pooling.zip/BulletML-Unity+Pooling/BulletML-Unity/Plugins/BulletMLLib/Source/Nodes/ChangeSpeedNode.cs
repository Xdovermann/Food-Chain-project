using System;
using System.Xml;

namespace BulletMLLib
{
  public class ChangeSpeedNode : BulletMLNode
  {
    public ChangeSpeedNode()
      : base(ENodeName.changeSpeed)
    {
    }
  }
}

using System;
using System.Xml;

namespace BulletMLLib
{
  public class TriggerNode : BulletMLNode
  {
    public TriggerNode()
      : base(ENodeName.trigger)
    {
    }
  }
}

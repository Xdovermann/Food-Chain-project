using System;
using System.Xml;

namespace BulletMLLib
{
  public class TermNode : BulletMLNode
  {
    public TermNode()
      : base(ENodeName.term)
    {
    }
  }
}

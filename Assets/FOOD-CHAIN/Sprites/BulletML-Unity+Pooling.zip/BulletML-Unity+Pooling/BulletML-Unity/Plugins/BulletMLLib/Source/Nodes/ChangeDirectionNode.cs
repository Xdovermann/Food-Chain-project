using System;
using System.Xml;

namespace BulletMLLib
{
  public class ChangeDirectionNode : BulletMLNode
  {
    public ChangeDirectionNode()
      : base(ENodeName.changeDirection)
    {
    }
  }
}

using System;
using System.Xml;

namespace BulletMLLib
{
  public class VanishNode : BulletMLNode
  {
    public VanishNode()
      : base(ENodeName.vanish)
    {
    }
  }
}

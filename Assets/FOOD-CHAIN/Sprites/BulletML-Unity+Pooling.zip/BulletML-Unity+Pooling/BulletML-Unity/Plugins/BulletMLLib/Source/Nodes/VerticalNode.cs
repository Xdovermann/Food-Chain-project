using System;
using System.Xml;

namespace BulletMLLib
{
  public class VerticalNode : BulletMLNode
  {
    public VerticalNode()
      : base(ENodeName.vertical)
    {
    }
  }
}
